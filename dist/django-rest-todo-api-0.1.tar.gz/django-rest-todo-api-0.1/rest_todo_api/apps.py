from django.apps import AppConfig


class RestTodoApiConfig(AppConfig):
    name = 'rest_todo_api'
